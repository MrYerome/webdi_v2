import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-diners',
  templateUrl: './diners.component.html',
  styleUrls: ['./diners.component.css']
})
export class DinersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
